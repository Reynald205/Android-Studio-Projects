package com.reynald205netzero.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.content.Context;

public class Topsecfragment extends Fragment{
    private static EditText TopTextInput;
    private static EditText BottomTextInput;
    TopsecListener actcommand;

    public interface TopsecListener{
        public void creatememe(String top,String bottom);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            actcommand = (TopsecListener) getActivity();
        }catch (ClassCastException e){
            throw new ClassCastException(getActivity().toString());
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.top_sec_fragment, container, false);
        TopTextInput = (EditText) view.findViewById(R.id.TopTextInput);
        BottomTextInput = (EditText) view.findViewById(R.id.BottomTextInput);
        final Button button = (Button) view.findViewById(R.id.Button);

        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        buttonClicked(v);
                    }
                }
        );
        return view;
    }

    public void buttonClicked(View view){
        actcommand.creatememe(TopTextInput.getText().toString(),BottomTextInput.getText().toString());
    }

}

